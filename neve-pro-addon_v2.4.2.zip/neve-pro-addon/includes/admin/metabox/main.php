<?php
/**
 * Page settings metabox.
 *
 * @package Neve Pro Addon
 */

namespace Neve_Pro\Admin;

use Neve\Admin\Metabox\Controls_Base;

/**
 * Class Main
 *
 * @package Neve Pro Addon
 */
class Main extends Controls_Base {
	/**
	 * Add controls.
	 */
	public function add_controls() {
	}
}
