
### How to generate the translation file? 

You can run the following commands to build the translation file: 
* `yarn install --frozen-lockfile`
* `yarn run build:makepot`
